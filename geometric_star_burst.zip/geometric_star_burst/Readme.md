# Vibrant Geometric Star Burst Animation ✨

A mesmerizing geometric star burst and glowing mandala animation built using Python's built-in **Turtle** graphics and trigonometric mathematics.

## Creator
- **Developed by:** codingwithvishesh

## Requirements

- Python 3.x (Turtle graphics comes pre-installed with Python)

## Folder Structure

```text
geometric_star_burst/
├── main.py
└── README.md